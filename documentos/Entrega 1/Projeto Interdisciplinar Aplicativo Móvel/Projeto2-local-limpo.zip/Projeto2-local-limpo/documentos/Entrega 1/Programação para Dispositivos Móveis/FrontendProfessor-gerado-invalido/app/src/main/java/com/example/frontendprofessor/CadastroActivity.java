package com.example.frontendprofessor;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class CadastroActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);
        EditText nome = findViewById(R.id.etNomeCadastro);
        EditText email = findViewById(R.id.etEmailCadastro);
        EditText senha = findViewById(R.id.etSenhaCadastro);
        TextView erro = findViewById(R.id.txtErroCadastro);
        Button cadastrar = findViewById(R.id.btnCadastrar);
        cadastrar.setOnClickListener(view -> {
            if (nome.getText().toString().trim().isEmpty() || email.getText().toString().trim().isEmpty() || senha.getText().toString().isEmpty()) {
                erro.setText("Preencha nome, e-mail e senha.");
                return;
            }
            Intent intent = new Intent(this, LoginActivity.class);
            intent.putExtra(LoginActivity.EXTRA_NOME, nome.getText().toString().trim());
            intent.putExtra(LoginActivity.EXTRA_EMAIL, email.getText().toString().trim());
            startActivity(intent);
        });
        findViewById(R.id.txtJaTenhoConta).setOnClickListener(view -> startActivity(new Intent(this, LoginActivity.class)));
    }
}
