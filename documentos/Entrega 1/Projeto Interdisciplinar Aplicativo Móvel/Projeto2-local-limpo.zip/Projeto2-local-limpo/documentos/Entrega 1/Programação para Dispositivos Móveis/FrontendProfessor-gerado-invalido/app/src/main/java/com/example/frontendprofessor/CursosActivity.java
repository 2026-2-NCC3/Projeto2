package com.example.frontendprofessor;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class CursosActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cursos);
        TextView detalhes = findViewById(R.id.txtDetalhesCurso);
        findViewById(R.id.btnCurso1).setOnClickListener(view -> mostrar(detalhes, "Curso 1"));
        findViewById(R.id.btnCurso2).setOnClickListener(view -> mostrar(detalhes, "Curso 2"));
        findViewById(R.id.btnVoltarCursos).setOnClickListener(view -> finish());
    }
    private void mostrar(TextView detalhes, String curso) {
        detalhes.setText(curso + "\n\nCarga horária: não informada no material-base.\n\nAtividades:\n1. Atividade 1\n2. Atividade 2");
        detalhes.setVisibility(View.VISIBLE);
    }
}
