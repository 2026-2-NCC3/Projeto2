package com.example.frontendprofessor;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class InicioActivity extends AppCompatActivity {
    public static final String EXTRA_NOME = "nomeAluno";
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);
        String nome = getIntent().getStringExtra(EXTRA_NOME);
        ((TextView) findViewById(R.id.txtSaudacao)).setText("Olá, " + (nome == null ? "Aluno" : nome) + "!");
        findViewById(R.id.btnMeusCursos).setOnClickListener(view -> startActivity(new Intent(this, CursosActivity.class)));
        findViewById(R.id.btnMinhaAgenda).setOnClickListener(view -> startActivity(new Intent(this, AgendaActivity.class)));
    }
}
