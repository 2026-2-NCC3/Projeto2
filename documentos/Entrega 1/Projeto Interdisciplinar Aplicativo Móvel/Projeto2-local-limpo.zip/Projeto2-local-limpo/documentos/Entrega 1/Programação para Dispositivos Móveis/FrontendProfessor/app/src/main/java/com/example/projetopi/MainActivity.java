package com.example.projetopi;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

// Tela 1: Login. Usa somente Activity, Views e Intent, como no exemplo do professor.
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText editEmail = findViewById(R.id.editEmail);
        EditText editSenha = findViewById(R.id.editSenha);
        TextView txtErroLogin = findViewById(R.id.txtErroLogin);

        findViewById(R.id.btnEntrar).setOnClickListener(view -> {
            String email = editEmail.getText().toString().trim();
            String senha = editSenha.getText().toString().trim();

            if (email.isEmpty() || senha.isEmpty()) {
                txtErroLogin.setText("Preencha o e-mail e a senha.");
                return;
            }

            // A Intent é a "mochila" que abre a próxima Activity.
            Intent intent = new Intent(MainActivity.this, TelaInicial.class);
            // O nome é extraído do e-mail apenas para demonstrar putExtra/getStringExtra.
            intent.putExtra("nomeUsuario", email.split("@")[0]);
            startActivity(intent);
        });
    }
}
