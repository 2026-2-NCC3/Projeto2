package com.example.frontendprofessor;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class AgendaActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agenda);
        findViewById(R.id.btnVoltarAgenda).setOnClickListener(view -> finish());
    }
}
