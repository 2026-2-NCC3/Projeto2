package com.example.projetopi;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

// Tela 3: Cursos. Mantém o dado recebido e o envia para as outras telas.
public class CursosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cursos);

        String nomeUsuario = getIntent().getStringExtra("nomeUsuario");
        if (nomeUsuario == null) {
            nomeUsuario = "Aluno";
        }

        final String nomeParaNavegacao = nomeUsuario;

        findViewById(R.id.navInicio).setOnClickListener(view -> {
            Intent intent = new Intent(CursosActivity.this, TelaInicial.class);
            intent.putExtra("nomeUsuario", nomeParaNavegacao);
            startActivity(intent);
        });

        findViewById(R.id.navAgenda).setOnClickListener(view -> {
            Intent intent = new Intent(CursosActivity.this, AgendaActivity.class);
            intent.putExtra("nomeUsuario", nomeParaNavegacao);
            startActivity(intent);
        });
    }
}

