package com.example.frontendprofessor;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    public static final String EXTRA_NOME = "nomeAluno";
    public static final String EXTRA_EMAIL = "emailAluno";
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        EditText email = findViewById(R.id.etEmailLogin);
        EditText senha = findViewById(R.id.etSenhaLogin);
        TextView erro = findViewById(R.id.txtErroLogin);
        String nome = getIntent().getStringExtra(EXTRA_NOME);
        String emailRecebido = getIntent().getStringExtra(EXTRA_EMAIL);
        if (emailRecebido != null) email.setText(emailRecebido);
        Button entrar = findViewById(R.id.btnEntrar);
        entrar.setOnClickListener(view -> {
            if (email.getText().toString().trim().isEmpty() || senha.getText().toString().isEmpty()) {
                erro.setText("Informe e-mail e senha para entrar.");
                return;
            }
            Intent intent = new Intent(this, InicioActivity.class);
            intent.putExtra(InicioActivity.EXTRA_NOME, nome == null ? "Aluno" : nome);
            startActivity(intent);
            finish();
        });
    }
}
