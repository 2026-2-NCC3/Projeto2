package com.example.projetopi;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

// Tela 4: Agenda. Mantém o mesmo padrão de Intent do exemplo do professor.
public class AgendaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agenda);

        String nomeUsuario = getIntent().getStringExtra("nomeUsuario");
        if (nomeUsuario == null) {
            nomeUsuario = "Aluno";
        }

        final String nomeParaNavegacao = nomeUsuario;

        findViewById(R.id.navInicio).setOnClickListener(view -> {
            Intent intent = new Intent(AgendaActivity.this, TelaInicial.class);
            intent.putExtra("nomeUsuario", nomeParaNavegacao);
            startActivity(intent);
        });

        findViewById(R.id.navCursos).setOnClickListener(view -> {
            Intent intent = new Intent(AgendaActivity.this, CursosActivity.class);
            intent.putExtra("nomeUsuario", nomeParaNavegacao);
            startActivity(intent);
        });
    }
}

