plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.projetopi"
    compileSdk = 37
    defaultConfig {
        applicationId = "com.example.frontendprofessor"
        minSdk = 24
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.8.0")
    implementation("androidx.activity:activity:1.13.0")
    implementation("androidx.constraintlayout:constraintlayout:2.2.2")
    implementation("com.google.android.material:material:1.14.0")
    implementation("de.hdodenhof:circleimageview:3.1.0")
}
