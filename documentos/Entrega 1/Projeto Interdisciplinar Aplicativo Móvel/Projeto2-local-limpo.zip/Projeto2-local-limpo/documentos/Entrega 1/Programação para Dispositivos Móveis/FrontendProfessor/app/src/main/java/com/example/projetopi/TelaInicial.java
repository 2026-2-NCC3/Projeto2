package com.example.projetopi;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

// Tela 2: Início. Recebe o nome enviado pelo Login e o repassa nas navegações.
public class TelaInicial extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paginainicial);

        String nomeUsuario = getIntent().getStringExtra("nomeUsuario");
        if (nomeUsuario == null || nomeUsuario.trim().isEmpty()) {
            nomeUsuario = "Aluno";
        }

        ((TextView) findViewById(R.id.txtSaudacao))
                .setText("Olá, " + nomeUsuario + "! 👋");

        final String nomeParaNavegacao = nomeUsuario;

        findViewById(R.id.navCursos).setOnClickListener(view -> {
            Intent intent = new Intent(TelaInicial.this, CursosActivity.class);
            intent.putExtra("nomeUsuario", nomeParaNavegacao);
            startActivity(intent);
        });

        findViewById(R.id.atalhoCursos).setOnClickListener(view -> {
            Intent intent = new Intent(TelaInicial.this, CursosActivity.class);
            intent.putExtra("nomeUsuario", nomeParaNavegacao);
            startActivity(intent);
        });

        findViewById(R.id.navAgenda).setOnClickListener(view -> {
            Intent intent = new Intent(TelaInicial.this, AgendaActivity.class);
            intent.putExtra("nomeUsuario", nomeParaNavegacao);
            startActivity(intent);
        });

        findViewById(R.id.atalhoAgenda).setOnClickListener(view -> {
            Intent intent = new Intent(TelaInicial.this, AgendaActivity.class);
            intent.putExtra("nomeUsuario", nomeParaNavegacao);
            startActivity(intent);
        });
    }
}

